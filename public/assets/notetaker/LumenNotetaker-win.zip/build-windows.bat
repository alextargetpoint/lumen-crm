@echo off
REM Lumen Notetaker — сборка .exe под Windows (один файл, без консоли)
REM Требуется: Python 3.10+ в PATH. Запускать на Windows.
setlocal
echo [1/3] Установка зависимостей...
python -m pip install --upgrade pip
python -m pip install -r requirements-windows.txt pyinstaller
echo [2/3] Сборка LumenNotetaker.exe...
python -m PyInstaller --noconfirm --onefile --windowed --name "LumenNotetaker" ^
  --collect-all soundcard --collect-all soundfile ^
  notetaker.py
echo [3/3] Готово. EXE: dist\LumenNotetaker.exe
echo Положите config.json рядом с LumenNotetaker.exe (см. config.example.json).
endlocal
