@echo off
REM Lumen Notetaker — запуск на Windows без сборки .exe (нужен Python 3.10+)
cd /d "%~dp0"
if not exist config.json (
  copy config.example.json config.json >nul
  echo.
  echo Создан config.json. Впишите crm_key (секрет хуков из дашборда Lumen), broker_id по желанию.
  echo audio_device оставьте пустым — звук берётся без кабеля (WASAPI).
  echo.
  notepad config.json
  echo После сохранения config.json запустите run-windows.bat снова.
  pause
  exit /b
)
echo Устанавливаю зависимости (один раз)...
python -m pip install --quiet --upgrade pip
python -m pip install --quiet -r requirements-windows.txt
echo Запускаю Lumen Notetaker (иконка появится в системном трее)...
python notetaker.py
pause
