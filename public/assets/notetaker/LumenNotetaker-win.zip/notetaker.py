#!/usr/bin/env python3
"""
Lumen Notetaker — фоновый нотетейкер звонков (мак/Windows/Linux брокера). Трей + авто-привязка к карточке.

ИДЕАЛЬНАЯ СВЯЗЬ (какой Zoom → какая карточка, без ручного выбора):
  Встреча планируется в Lumen → у неё есть zoomMeetingId + leadId. Приложение спрашивает CRM
  «что у меня сейчас по расписанию» (/hooks/notetaker-agenda) и привязывает звонок к карточке:
    1) по номеру Zoom-встречи, если удаётся его прочитать;
    2) иначе — к встрече, которая «идёт сейчас» (live по времени у этого брокера).
  Транскрипт уходит с meetingId → падает ровно в нужную карточку. Ad-hoc звонок (нет в расписании)
  → трей-меню предложит выбрать лида / записать вручную.

Клиент НЕ видит запись: Zoom не пишет, бот не заходит — аудио берётся локально.

ЗАХВАТ ЗВУКА:
  • macOS/Linux — ffmpeg (avfoundation/pulse), устройство из config.audio_device.
  • Windows — WASAPI loopback (библиотека `soundcard`): системный звук (= голос собеседника) + микрофон
    (= ваш голос) пишутся и МИКШИРУЮТСЯ. Виртуальный кабель (VB-CABLE) НЕ нужен. Фолбэк — ffmpeg dshow,
    если задан config.audio_device.

ЗАПУСК (трей):    pip install -r requirements-windows.txt ; python notetaker.py     (Windows/Linux: pystray)
ЗАПУСК (mac):     pip3 install rumps requests pyobjc ; python3 notetaker.py         (менюбар rumps)
ЗАПУСК (headless):python notetaker.py --headless
"""
import json, os, sys, time, subprocess, tempfile, signal, datetime, threading, platform, base64, urllib.request, urllib.error, urllib.parse, re

HERE = os.path.dirname(os.path.abspath(sys.executable if getattr(sys, "frozen", False) else __file__))
def _cfg_path():
    # frozen .exe: config.json рядом с exe; dev: рядом со скриптом
    for p in [os.path.join(HERE, "config.json"), os.path.join(os.getcwd(), "config.json")]:
        if os.path.exists(p): return p
    return os.path.join(HERE, "config.json")
CFG = json.load(open(_cfg_path(), encoding="utf-8"))
CRM   = CFG["crm_base"].rstrip("/")
KEY   = CFG["crm_key"]
BROKER = CFG.get("broker_id", "")
ADEV  = str(CFG.get("audio_device", "") or "")
OS    = platform.system()   # Darwin / Windows / Linux
STT_LOCAL = CFG.get("stt_local")   # {"bin":..., "model_path":..., "lang":"ru"} если хочешь локально

def log(*a): print(datetime.datetime.now().strftime("%H:%M:%S"), *a, flush=True)

# ───────────────────────── CRM ─────────────────────────
def _get(path):
    with urllib.request.urlopen(CRM + path, timeout=30) as r: return json.loads(r.read().decode())
def agenda():
    try: return _get("/hooks/notetaker-agenda?key=%s&broker=%s" % (urllib.parse.quote(KEY), urllib.parse.quote(BROKER))).get("meetings", [])
    except Exception as e: log("agenda err:", e); return []
def search_leads(q):
    try: return _get("/hooks/notetaker-leads?key=%s&q=%s" % (urllib.parse.quote(KEY), urllib.parse.quote(q))).get("leads", [])
    except Exception: return []
def upload_audio(path):
    """залить запись → URL (сервер хранит файл, не base64 в БД)"""
    ext = os.path.splitext(path)[1].lstrip(".") or "wav"
    mime = {"wav": "wav", "m4a": "mp4", "mp3": "mpeg", "ogg": "ogg"}.get(ext, ext)
    dataurl = "data:audio/%s;base64,%s" % (mime, base64.b64encode(open(path, "rb").read()).decode())
    data = json.dumps({"data": dataurl}).encode()
    req = urllib.request.Request(CRM + "/hooks/notetaker-audio?key=" + urllib.parse.quote(KEY), data=data, headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=300) as r: return json.loads(r.read().decode()).get("url")
    except Exception as e: log("upload_audio err:", e); return None

def post_transcript(text, lead_id=None, meeting_id=None, zoom_id=None, audio_url=None, started_at=None, dur=60, label="локальная запись"):
    p = {"startedAt": started_at or int(time.time()*1000), "dur": dur, "label": label}
    if text: p["text"] = text          # пусто → сервер расшифрует audio сам (платформенный Groq)
    if audio_url: p["audio"] = audio_url
    if meeting_id or zoom_id: p["meetingId"] = meeting_id or zoom_id
    if lead_id: p["leadId"] = lead_id
    data = json.dumps(p).encode()
    req = urllib.request.Request(CRM + "/hooks/notetaker?key=" + urllib.parse.quote(KEY), data=data, headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=120) as r: return True, r.read().decode()[:160]
    except urllib.error.HTTPError as e: return False, "%d %s" % (e.code, e.read().decode()[:160])
    except Exception as e: return False, str(e)[:160]

# ───────────────────── детект звонка ─────────────────────
FORCE = {"on": False}   # ручной старт/стоп из трея (для Meet-в-браузере и ad-hoc)
CALL_APPS_WIN = ["zoom.exe", "cpthost.exe", "teams.exe", "ms-teams.exe", "msteams.exe", "webexmta.exe", "webex.exe", "slack.exe"]

def _win_tasklist():
    try:
        out = subprocess.run(["tasklist", "/fo", "csv", "/nh"], capture_output=True, text=True,
                             creationflags=0x08000000 if OS == "Windows" else 0).stdout.lower()  # CREATE_NO_WINDOW
        return out
    except Exception: return ""

def meeting_running():
    if FORCE["on"]: return True   # ручной режим — пишем, пока не остановят
    try:
        if OS == "Windows":
            tl = _win_tasklist()
            return any(app in tl for app in CALL_APPS_WIN)
        # macOS / Linux
        if subprocess.run(["pgrep", "-x", "CptHost"], capture_output=True).returncode == 0: return True  # Zoom во время звонка
        out = subprocess.run(["pgrep", "-il", "zoom|Teams"], capture_output=True, text=True).stdout.lower()
        return "zoom" in out or "teams" in out
    except Exception: return False

def read_zoom_meeting_id():
    """best-effort: вытащить номер Zoom-встречи из заголовка окна (если показан)"""
    try:
        if OS == "Windows":
            try:
                import pygetwindow as gw
                titles = " ".join([w.title for w in gw.getAllWindows() if w.title])
            except Exception:
                titles = ""
            m = re.search(r"\b(\d{9,12})\b", titles)
            return m.group(1) if m else ""
        s = subprocess.run(["osascript", "-e",
            'tell application "System Events" to tell process "zoom.us" to get name of windows'],
            capture_output=True, text=True, timeout=4).stdout
        m = re.search(r"\b(\d{9,12})\b", s)
        return m.group(1) if m else ""
    except Exception: return ""

def match_meeting(zoom_id):
    """какой карточке принадлежит звонок: по номеру Zoom, иначе — live-встреча по времени"""
    ag = agenda()
    if zoom_id:
        for m in ag:
            if m.get("zoomMeetingId") and str(m["zoomMeetingId"]) == str(zoom_id): return m, "по номеру Zoom"
    live = [m for m in ag if m.get("live")]
    if len(live) == 1: return live[0], "по расписанию (идёт сейчас)"
    if len(live) > 1: return None, "несколько встреч сейчас — выбери лида"
    return None, "нет встречи в расписании — ad-hoc"

# ───────────────────── запись + STT ─────────────────────
def _ff_input():
    """вход ffmpeg по ОС: macOS avfoundation / Windows dshow / Linux pulse. ADEV — устройство из config."""
    if OS == "Darwin":  return ["-f", "avfoundation", "-i", ":" + (ADEV or "0")]
    if OS == "Windows": return ["-f", "dshow", "-i", "audio=" + ADEV]   # фолбэк: ADEV = имя dshow-устройства (VB-CABLE)
    return ["-f", "pulse", "-i", ADEV or "default"]

def _record_ffmpeg(out):
    ff = subprocess.Popen(["ffmpeg", "-y"] + _ff_input() + ["-ac", "1", "-ar", "16000", "-c:a", "aac", "-b:a", "32k", out],
                          stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    gone = 0
    while True:
        time.sleep(5)
        gone = gone + 5 if not meeting_running() else 0
        if gone >= 8: break
    try: ff.communicate(b"q", timeout=5)
    except Exception:
        try: ff.send_signal(signal.SIGINT); ff.wait(timeout=5)
        except Exception:
            try: ff.terminate()
            except Exception: pass

def _record_windows_wasapi(out):
    """Windows без кабеля: WASAPI-loopback (системный звук = собеседник) + микрофон (ваш голос) → микс в WAV.
       Два потока пишут параллельно, по стопу микшируем и сохраняем."""
    import numpy as np, soundcard as sc, soundfile as sf
    sr = 16000
    stop = threading.Event()
    sys_frames, mic_frames = [], []

    def rec_loopback():
        try:
            spk = sc.default_speaker()
            loop = None
            for m in sc.all_microphones(include_loopback=True):
                if getattr(m, "isloopback", False) and spk.name.split()[0].lower() in m.name.lower():
                    loop = m; break
            if loop is None:
                loop = sc.get_microphone(spk.name, include_loopback=True)
            with loop.recorder(samplerate=sr, channels=1) as r:
                while not stop.is_set():
                    sys_frames.append(r.record(numframes=sr // 2))
        except Exception as e:
            log("loopback rec err:", e)

    def rec_mic():
        try:
            mic = sc.default_microphone()
            with mic.recorder(samplerate=sr, channels=1) as r:
                while not stop.is_set():
                    mic_frames.append(r.record(numframes=sr // 2))
        except Exception as e:
            log("mic rec err:", e)

    t1 = threading.Thread(target=rec_loopback, daemon=True); t2 = threading.Thread(target=rec_mic, daemon=True)
    t1.start(); t2.start()
    gone = 0
    while True:
        time.sleep(5)
        gone = gone + 5 if not meeting_running() else 0
        if gone >= 8: break
    stop.set(); t1.join(timeout=4); t2.join(timeout=4)

    def _cat(frames):
        if not frames: return np.zeros((0, 1), dtype="float32")
        return np.concatenate(frames, axis=0).astype("float32")
    a = _cat(sys_frames); b = _cat(mic_frames)
    n = max(len(a), len(b))
    if n == 0: raise RuntimeError("пустая запись (нет аудио)")
    def _pad(x):
        if len(x) < n: x = np.pad(x, ((0, n - len(x)), (0, 0)))
        return x[:n]
    mix = np.clip(_pad(a) * 0.92 + _pad(b) * 0.92, -1.0, 1.0)
    sf.write(out, mix, sr)   # WAV 16k mono

def record_until_end(out):
    """запись до конца звонка. Windows → WASAPI (без кабеля), фолбэк ffmpeg если задан audio_device / нет soundcard."""
    if OS == "Windows" and not ADEV:
        try:
            _record_windows_wasapi(out); return
        except Exception as e:
            log("WASAPI недоступен (%s) — фолбэк на ffmpeg. Для захвата без кабеля: pip install soundcard soundfile numpy" % e)
    _record_ffmpeg(out)

def rec_ext():
    return "wav" if (OS == "Windows" and not ADEV) else "m4a"

def transcribe_local(path):
    """опционально: локальный whisper.cpp ($0). По умолчанию НЕ используется — расшифровку делает сервер."""
    if not STT_LOCAL: return ""
    try:
        subprocess.run([STT_LOCAL.get("bin", "whisper.cpp/main"), "-m", STT_LOCAL.get("model_path", "whisper.cpp/models/ggml-base.bin"),
                        "-f", path, "-otxt", "-l", STT_LOCAL.get("lang", "ru")], check=True)
        return open(path + ".txt", encoding="utf-8").read().strip()
    except Exception as e: log("local STT err:", e); return ""

# ───────────────────── ядро сессии ─────────────────────
STATE = {"status": "жду звонок", "lead": "", "last": ""}
def on_status(cb=None):
    def setf(s, lead=""):
        STATE["status"] = s; STATE["lead"] = lead
        log("•", s, ("→ " + lead) if lead else "")
        if cb: cb()
    return setf

def session_loop(setst, pick_lead=None):
    while True:
        if meeting_running():
            t0 = time.time()
            zid = read_zoom_meeting_id()
            mt, how = match_meeting(zid)
            lead_name = mt["leadName"] if mt else ""
            setst("🔴 идёт запись — %s" % how, lead_name or "лид не определён")
            out = os.path.join(tempfile.gettempdir(), "lumen_%d.%s" % (int(t0), rec_ext()))
            try:
                record_until_end(out)
            except Exception as e:
                setst("❌ ошибка записи: %s" % str(e)[:60]); setst("жду звонок"); time.sleep(5); continue
            dur = max(1, int((time.time() - t0) / 60))
            setst("☁️ отправляю на расшифровку…", lead_name)
            if not mt and pick_lead: mt = pick_lead()        # ad-hoc — спросить лида
            audio_url = upload_audio(out)
            text = transcribe_local(out)                     # пусто → сервер расшифрует сам (платформенный Groq)
            try: os.remove(out)
            except Exception: pass
            ok, msg = post_transcript(text, lead_id=(mt or {}).get("leadId"),
                                      meeting_id=(mt or {}).get("meetingId"), zoom_id=zid,
                                      audio_url=audio_url, started_at=int(t0*1000), dur=dur)
            STATE["last"] = ("✅ " if ok else "❌ ") + (lead_name or "лид?") + " · " + datetime.datetime.now().strftime("%H:%M")
            setst("✅ отправлено" if ok else "❌ не отправлено: " + msg, lead_name)
            if FORCE["on"]: FORCE["on"] = False   # ручная запись завершилась — сбрасываем флаг
            setst("жду звонок")
        time.sleep(5)

# ───────────────────── трей: menubar (mac) / pystray (Windows·Linux) / headless ─────────────────────
def run_menubar():
    import rumps
    class App(rumps.App):
        def __init__(self):
            super().__init__("Lumen", icon=None, title="◉", quit_button="Выйти")
            self.item_status = rumps.MenuItem("жду звонок")
            self.item_lead = rumps.MenuItem("лид: —")
            self.item_last = rumps.MenuItem("последний: —")
            self.menu = [self.item_status, self.item_lead, None, self.item_last, None,
                         rumps.MenuItem("▶ Записать вручную", callback=lambda _: FORCE.__setitem__("on", True)),
                         rumps.MenuItem("■ Остановить запись", callback=lambda _: FORCE.__setitem__("on", False)),
                         rumps.MenuItem("Открыть Lumen", callback=lambda _: subprocess.run(["open", CRM]))]
            def refresh():
                self.title = "🔴" if "запись" in STATE["status"] else "◉"
                self.item_status.title = STATE["status"]
                self.item_lead.title = "лид: " + (STATE["lead"] or "—")
                self.item_last.title = "последний: " + (STATE["last"] or "—")
            self._refresh = refresh
            threading.Thread(target=session_loop, args=(on_status(lambda: self._safe()),), daemon=True).start()
        def _safe(self):
            try: self._refresh()
            except Exception: pass
        @rumps.timer(2)
        def _tick(self, _): self._safe()
    App().run()

def _tray_icon(active):
    """иконка трея: круг (серый = ждём, красный = запись)"""
    from PIL import Image, ImageDraw
    img = Image.new("RGBA", (64, 64), (0, 0, 0, 0)); d = ImageDraw.Draw(img)
    col = (200, 60, 50, 255) if active else (40, 40, 40, 255)
    d.ellipse((14, 14, 50, 50), fill=col)
    return img

def run_tray():
    """Windows/Linux: системный трей через pystray."""
    import pystray
    def _open(*_):
        try:
            if OS == "Windows": os.startfile(CRM)
            else: subprocess.run(["xdg-open", CRM])
        except Exception: pass
    icon = pystray.Icon("lumen", _tray_icon(False), "Lumen Notetaker")
    def menu():
        return pystray.Menu(
            pystray.MenuItem(lambda i: STATE["status"], None, enabled=False),
            pystray.MenuItem(lambda i: "лид: " + (STATE["lead"] or "—"), None, enabled=False),
            pystray.MenuItem(lambda i: "последний: " + (STATE["last"] or "—"), None, enabled=False),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("▶ Записать вручную", lambda i: FORCE.__setitem__("on", True)),
            pystray.MenuItem("■ Остановить запись", lambda i: FORCE.__setitem__("on", False)),
            pystray.MenuItem("Открыть Lumen", _open),
            pystray.MenuItem("Выйти", lambda i: i.stop()),
        )
    icon.menu = menu()
    def refresh():
        active = "запись" in STATE["status"]
        try: icon.icon = _tray_icon(active); icon.title = "Lumen · " + STATE["status"]; icon.update_menu()
        except Exception: pass
    threading.Thread(target=session_loop, args=(on_status(refresh),), daemon=True).start()
    icon.run()

def run_headless():
    log("headless режим — пишу по авто-детекту звонка. Ручной старт: создайте файл FORCE рядом (не обязательно).")
    session_loop(on_status())

if __name__ == "__main__":
    if "--headless" in sys.argv:
        run_headless()
    elif OS == "Darwin":
        try: run_menubar()
        except ImportError:
            log("rumps не установлен (pip3 install rumps pyobjc) — работаю headless"); run_headless()
    else:
        try: run_tray()
        except ImportError:
            log("pystray/Pillow не установлены (pip install pystray pillow) — работаю headless"); run_headless()
